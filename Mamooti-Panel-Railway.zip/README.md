# Mamooti Panel

پنل مدیریتی تاریک و مدرن، آماده‌ی Deploy روی Railway.

## امکانات
- داشبورد مدیریتی
- ورود ادمین با session امن و JWT
- PostgreSQL برای ذخیره‌سازی پایدار
- ساخت و مدیریت Subscription
- لینک عمومی `/sub/TOKEN`
- انقضا و فعال/غیرفعال بودن اشتراک
- رابط RTL و موبایل‌پسند
- Health check در `/health`
- تنظیم Railway برای Amsterdam

## Deploy روی Railway

1. این پروژه را در یک GitHub repository قرار بده.
2. در Railway یک Project بساز و **Deploy from GitHub Repo** را انتخاب کن.
3. یک سرویس PostgreSQL به همان Project اضافه کن.
4. متغیر `DATABASE_URL` سرویس اپ را به `Postgres.DATABASE_URL` reference کن.
5. این متغیرها را برای اپ بساز:
   - `JWT_SECRET` = یک رشته تصادفی طولانی
   - `ADMIN_USERNAME` = نام کاربری دلخواه
   - `ADMIN_PASSWORD` = رمز قوی دلخواه
   - `PUBLIC_BASE_URL` = دامنه نهایی پنل، مثلاً `https://panel.example.com`
6. در Settings → Deploy/Scale منطقه را روی **Amsterdam / EU West Metal** بگذار. فایل `railway.json` نیز region را روی `europe-west4-drams3a` تنظیم کرده است.
7. از Networking یک Railway Domain بساز یا دامنه شخصی اضافه کن.
8. بعد از تغییر `PUBLIC_BASE_URL` یک redeploy انجام بده.

## اجرای محلی

```bash
npm install
cp .env.example .env
npm start
```

بدون PostgreSQL هم برای تست UI می‌توانی اجرا کنی، ولی داده‌ها در حافظه هستند و با restart از بین می‌روند. برای Railway از PostgreSQL استفاده کن.

## نکته
این پروژه یک پنل عمومی برای مدیریت داده‌های Subscription است و endpoint اشتراک صرفاً محتوایی را که ادمین ذخیره کرده برمی‌گرداند.
