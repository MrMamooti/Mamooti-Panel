require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { Pool } = require("pg");

const app = express();
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString("hex");
const BASE_URL = (process.env.PUBLIC_BASE_URL || "").replace(/\/$/, "");
const pool = process.env.DATABASE_URL ? new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false }
}) : null;

const mem = { users: [], subs: [] };

async function dbQuery(text, params=[]) {
  if (!pool) return null;
  return pool.query(text, params);
}

async function initDb() {
  if (!pool) return;
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admins (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS subscriptions (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      token TEXT UNIQUE NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      expires_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT now()
    );
  `);
  const admin = await pool.query("SELECT id FROM admins LIMIT 1");
  if (!admin.rowCount) {
    const username = process.env.ADMIN_USERNAME || "admin";
    const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString("base64url");
    const hash = await bcrypt.hash(password, 12);
    await pool.query("INSERT INTO admins (username, password_hash) VALUES ($1,$2)", [username, hash]);
    console.log(`Initial admin username: ${username}`);
    if (!process.env.ADMIN_PASSWORD) console.log(`Initial admin password: ${password}`);
  }
}

function signAdmin(username) {
  return jwt.sign({ sub: username, role: "admin" }, JWT_SECRET, { expiresIn: "7d" });
}

function auth(req, res, next) {
  const token = req.cookies.mamooti_session;
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== "admin") throw new Error("role");
    req.admin = payload;
    next();
  } catch {
    res.redirect("/login");
  }
}

function esc(v="") {
  return String(v).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;" }[c]));
}

function layout(title, body) {
  return `<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} · Mamooti Panel</title>
<link rel="stylesheet" href="/style.css">
</head><body>${body}</body></html>`;
}

function shell(active, content) {
  return layout(active, `<div class="app">
<aside class="sidebar">
  <div class="brand"><div class="logo">M</div><div><b>Mamooti</b><span>Panel</span></div></div>
  <nav>
    <a class="${active==="داشبورد"?"active":""}" href="/">⌂ <span>داشبورد</span></a>
    <a class="${active==="اشتراک‌ها"?"active":""}" href="/subscriptions">⌁ <span>اشتراک‌ها</span></a>
    <a href="/logout">↪ <span>خروج</span></a>
  </nav>
  <div class="side-note">EU · Amsterdam<br><small>Railway Ready</small></div>
</aside>
<main class="main">${content}</main></div>`);
}

function formatDate(v) {
  if (!v) return "بدون انقضا";
  return new Date(v).toLocaleDateString("fa-IR");
}

app.get("/health", (_,res)=>res.status(200).json({ok:true, panel:"Mamooti Panel"}));

app.get("/login", (req,res)=>{
  if (req.cookies.mamooti_session) return res.redirect("/");
  res.send(layout("ورود", `<div class="login-wrap"><div class="login-card">
    <div class="brand center"><div class="logo">M</div><div><b>Mamooti</b><span>Panel</span></div></div>
    <h1>ورود به پنل</h1><p>مدیریت ساده، ظاهر جدی.</p>
    ${req.query.error ? `<div class="alert">نام کاربری یا رمز عبور اشتباه است.</div>` : ""}
    <form method="post" action="/login">
      <label>نام کاربری<input name="username" autocomplete="username" required></label>
      <label>رمز عبور<input name="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary full">ورود</button>
    </form>
  </div></div>`));
});

app.post("/login", async (req,res)=>{
  const {username,password} = req.body;
  let ok=false;
  if (pool) {
    const r=await pool.query("SELECT password_hash FROM admins WHERE username=$1",[username]);
    ok = r.rowCount ? await bcrypt.compare(password,r.rows[0].password_hash) : false;
  } else {
    ok = username === (process.env.ADMIN_USERNAME||"admin") && password === (process.env.ADMIN_PASSWORD||"admin123");
  }
  if (!ok) return res.redirect("/login?error=1");
  res.cookie("mamooti_session", signAdmin(username), {httpOnly:true, sameSite:"lax", secure:process.env.NODE_ENV==="production", maxAge:7*24*3600*1000});
  res.redirect("/");
});

app.get("/logout",(req,res)=>{res.clearCookie("mamooti_session");res.redirect("/login");});

async function listSubs() {
  if (!pool) return mem.subs;
  return (await pool.query("SELECT * FROM subscriptions ORDER BY id DESC")).rows;
}

app.get("/", auth, async (req,res)=>{
  const subs=await listSubs();
  const active=subs.filter(x=>x.status==="active").length;
  res.send(shell("داشبورد", `<header class="top"><div><span class="eyebrow">CONTROL CENTER</span><h1>داشبورد</h1><p>خوش آمدی به Mamooti Panel.</p></div><a class="btn primary" href="/subscriptions/new">＋ ساخت اشتراک</a></header>
  <section class="stats">
    <div class="stat"><span>کل اشتراک‌ها</span><b>${subs.length}</b><small>Subscription</small></div>
    <div class="stat"><span>فعال</span><b>${active}</b><small>Active</small></div>
    <div class="stat"><span>منطقه</span><b>EU</b><small>Amsterdam</small></div>
  </section>
  <section class="panel"><div class="panel-head"><h2>آخرین اشتراک‌ها</h2><a href="/subscriptions">مشاهده همه</a></div>
  ${subs.slice(0,5).map(s=>`<div class="row"><div><b>${esc(s.name)}</b><small>${esc(s.token)}</small></div><span class="badge ${s.status}">${s.status==="active"?"فعال":"غیرفعال"}</span><span>${formatDate(s.expires_at)}</span></div>`).join("") || `<div class="empty">هنوز اشتراکی ساخته نشده.</div>`}
  </section>`));
});

app.get("/subscriptions", auth, async (req,res)=>{
  const subs=await listSubs();
  res.send(shell("اشتراک‌ها", `<header class="top"><div><span class="eyebrow">SUBSCRIPTIONS</span><h1>اشتراک‌ها</h1><p>لینک‌های اختصاصی را از همین‌جا مدیریت کن.</p></div><a class="btn primary" href="/subscriptions/new">＋ ساخت اشتراک</a></header>
  <section class="panel"><div class="panel-head"><h2>لیست اشتراک‌ها</h2><span>${subs.length} مورد</span></div>
  ${subs.map(s=>`<div class="row wide"><div><b>${esc(s.name)}</b><small>${esc(s.token)}</small></div><span class="badge ${s.status}">${s.status==="active"?"فعال":"غیرفعال"}</span><span>${formatDate(s.expires_at)}</span><div class="actions"><a class="btn ghost" href="/subscriptions/${s.id}">مدیریت</a></div></div>`).join("") || `<div class="empty">هنوز داده‌ای وجود ندارد.</div>`}
  </section>`));
});

app.get("/subscriptions/new", auth, (req,res)=>{
  res.send(shell("اشتراک‌ها", `<header class="top"><div><span class="eyebrow">NEW SUBSCRIPTION</span><h1>ساخت اشتراک</h1><p>یک نام و محتوای اشتراک وارد کن.</p></div></header>
  <section class="form-card"><form method="post" action="/subscriptions">
  <label>نام اشتراک<input name="name" placeholder="مثلاً Mamooti VIP" required></label>
  <label>تاریخ انقضا <small>(اختیاری)</small><input name="expires_at" type="date"></label>
  <label>محتوای Subscription<textarea name="content" rows="9" placeholder="محتوای اشتراک یا داده‌ای که باید از لینک عمومی برگردد..."></textarea></label>
  <div class="hint">لینک عمومی بعد از ساخت به شکل <code>/sub/TOKEN</code> خواهد بود.</div>
  <button class="btn primary">ساخت اشتراک</button> <a class="btn ghost" href="/subscriptions">انصراف</a>
  </form></section>`));
});

app.post("/subscriptions", auth, async (req,res)=>{
  const name=String(req.body.name||"").trim();
  if (!name) return res.redirect("/subscriptions/new");
  const token=crypto.randomBytes(18).toString("base64url");
  const content=String(req.body.content||"");
  const expires=req.body.expires_at ? new Date(req.body.expires_at) : null;
  if (pool) await pool.query("INSERT INTO subscriptions(name,token,content,expires_at) VALUES($1,$2,$3,$4)",[name,token,content,expires]);
  else mem.subs.unshift({id:Date.now(),name,token,content,status:"active",expires_at:expires});
  res.redirect("/subscriptions");
});

app.get("/subscriptions/:id", auth, async (req,res)=>{
  let s;
  if(pool){const r=await pool.query("SELECT * FROM subscriptions WHERE id=$1",[req.params.id]);s=r.rows[0];}
  else s=mem.subs.find(x=>String(x.id)===String(req.params.id));
  if(!s) return res.status(404).send("Not found");
  const base=BASE_URL || `${req.protocol}://${req.get("host")}`;
  const url=`${base}/sub/${s.token}`;
  res.send(shell("اشتراک‌ها", `<header class="top"><div><span class="eyebrow">SUBSCRIPTION</span><h1>${esc(s.name)}</h1><p>مدیریت لینک عمومی</p></div><a class="btn ghost" href="/subscriptions">بازگشت</a></header>
  <section class="form-card"><label>لینک Subscription<input id="suburl" value="${esc(url)}" readonly></label>
  <button class="btn primary" onclick="navigator.clipboard.writeText(document.getElementById('suburl').value);this.textContent='کپی شد ✓'">کپی لینک</button>
  <hr><div class="meta-grid"><div><span>توکن</span><b>${esc(s.token)}</b></div><div><span>وضعیت</span><b>${s.status==="active"?"فعال":"غیرفعال"}</b></div><div><span>انقضا</span><b>${formatDate(s.expires_at)}</b></div></div>
  <div class="hint">این endpoint فقط محتوای ذخیره‌شده‌ی این اشتراک را ارائه می‌کند.</div></section>`));
});

app.get("/sub/:token", async (req,res)=>{
  let s;
  if(pool){const r=await pool.query("SELECT * FROM subscriptions WHERE token=$1",[req.params.token]);s=r.rows[0];}
  else s=mem.subs.find(x=>x.token===req.params.token);
  if(!s || s.status!=="active") return res.status(404).type("text/plain").send("Subscription not found");
  if(s.expires_at && new Date(s.expires_at)<new Date()) return res.status(410).type("text/plain").send("Subscription expired");
  res.set("Cache-Control","no-store");
  res.type("text/plain").send(s.content || "# Mamooti Panel\n# Empty subscription");
});

initDb().then(()=>{
  app.listen(PORT, "0.0.0.0", ()=>console.log(`Mamooti Panel listening on ${PORT}`));
}).catch(err=>{console.error(err);process.exit(1);});
